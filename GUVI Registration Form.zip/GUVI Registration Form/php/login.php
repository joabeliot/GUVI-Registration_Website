<?php

include "db_conn.php";

$errors = [];
$data = [];

// Check connection
if($conn === false){
	die("ERROR: Could not connect. "
		. mysqli_connect_error());
}

if (isset($_POST['uname']) && isset($_POST['pass']) && isset($_POST['email'])) {

function validate($data){
	$data = trim($data);
	$data = stripslashes($data);
	$data = htmlspecialchars($data);
	return $data;
}

$uname = validate($_POST['uname']);
$pass = validate($_POST['pass']);
$email = $_POST['email'];

$select = "SELECT * FROM users WHERE user_name='$uname' AND password='$pass' AND name='$email'";
$res = mysqli_query($conn, $select);
$data['res'] = mysqli_fetch_assoc($res);

if (mysqli_num_rows($res) == 1){
    if ($data['res']['user_name'] == $uname && $data['res']['password'] == $pass && $data['res']['name'] == $email) {
        $session['name'] = $data['res']['user_name'];
        $session['email'] = $data['res']['name'];
        $data['session'] = $session;
        $data['success'] = true;
        $data['message'] = "Successfully Logged In as {$uname}";
        // header("Location: profile.html");
    }
    else{
    $errors['uname'] = 'Username, password or your email is wrong...';
    $errors['pass'] = 'Username, password or your email is wrong...';
    $errors['email'] = 'Username, password or your email is wrong...';
    // header("Location: login.html");
}

}else{
$errors['uname'] = 'Username, password or your email is wrong...';
$errors['pass'] = 'Username, password or your email is wrong...';
$errors['email'] = 'Username, password or your email is wrong...';   
}}

if (!empty($errors)) {
    $data['success'] = false;
    $data['errors'] = $errors;
}

echo json_encode($data);