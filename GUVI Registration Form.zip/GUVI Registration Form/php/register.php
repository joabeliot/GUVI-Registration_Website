<?php

include "db_conn.php";

$errors = [];
$data = [];
$sessionDat = [];
$uDat = [];
if (empty($_POST['uname'])) {
    $errors['uname'] = 'Name is required.';
}

if (empty($_POST['email'])) {
    $errors['email'] = 'Email is required.';
}

if (empty($_POST['pass'])) {
    $errors['pass'] = 'Password needs to be better. git gud.';
}

if (!empty($errors)) {
    $data['success'] = false;
    $data['errors'] = $errors;
}

// Check connection
if($conn === false){
	die("ERROR: Could not connect. "
		. mysqli_connect_error());
}

if (isset($_POST['uname']) && isset($_POST['pass']) && isset($_POST['email'])  && isset($_POST['dob'])  && isset($_POST['age'])  && isset($_POST['contact'])) {

function validate($data){
	$data = trim($data);
	$data = stripslashes($data);
	$data = htmlspecialchars($data);
	return $data;
}

$uname = validate($_POST['uname']);
$pass = validate($_POST['pass']);
$email = $_POST['email'];

$uDat['name'] = $uname;
$uDat['email'] = $email;
$uDat['age'] = $_POST['age'];
$uDat['dob'] = $_POST['dob'];
$uDat['contact'] = $_POST['contact'];

$data['dob'] = $_POST['dob'];
$data['age'] = $_POST['age'];
$data['contact'] = $_POST['contact'];

$getId = "SELECT * FROM `users` ORDER BY `users`.`id` DESC";
$resId = mysqli_query($conn, $getId);
$result = mysqli_fetch_assoc($resId);

if ($result == null){$data['ID'] = 0;}else{$data['ID'] = (int)$result['id'];}

$data['col'] = $collection;
$data['udat'] = $uDat;

$idToPush = strval($data['ID']+1);

// $stmt = $conn->prepare("INSERT INTO MyGuests (firstname, lastname, email) VALUES (?, ?, ?)");
$insert = $conn->prepare("INSERT INTO users VALUES (?, ?, ?, ?)");
$insert->bind_param("ssss",$idToPush, $uname, $pass, $email);
$insert->execute();

$data['success'] = true;
$data['message'] = "Successfully added you";
$insert->close();
$collection->insertOne($uDat);
}

echo json_encode($data);