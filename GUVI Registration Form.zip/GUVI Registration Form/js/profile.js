var currentUser = JSON.parse(sessionStorage.getItem("session"));
var message = "Logged in as "+currentUser['name'];

$(document).ready(function () {
    $("#msg").html('<p>'+message+'</p>');
    $("form").submit(function (event) {
      $(".form-group").removeClass("has-error");
      $(".help-block").remove();
      var formData = {
        dob: $('#dob').val(),
        age: $('#age').val(),
        contact: $('#num').val(),
        user: currentUser['name'],
        email: currentUser['email']
      };
  
      $.ajax({
        type: "POST",
        url: "../question/php/profile.php",
        data: formData,
        dataType: "json",
        encode: true,
      }).done(function (data) {
        sessionStorage.setItem("session", JSON.stringify(data['session']));
        if (data.success) {
          $("form").html(
            '<div class="alert alert-success">' + data.message + "</div>"
          );
        };
      event.preventDefault();
    });
  })});